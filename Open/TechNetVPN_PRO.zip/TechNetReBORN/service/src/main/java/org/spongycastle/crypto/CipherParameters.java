package org.spongycastle.crypto;

/**
 * all parameter classes implement this.
 */
public interface CipherParameters
{
}
