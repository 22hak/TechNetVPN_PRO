package https.socks.android.db;

import android.content.*;
import com.google.android.gms.ads.*;
import android.view.*;
import java.util.*;

import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;

import android.os.*;
import android.widget.*;
import android.widget.RelativeLayout.LayoutParams;
import android.graphics.Color;

public class AdmobHelper
{

    private Context context;

    private AdRequest.Builder adRequest;


    private AdRequest adR;

    private AdView adView;


    private static final String Inters = "ca-app-pub-3940256099942544/1033173712";
    private InterstitialAd interstitialAd;
    private RewardedAd rewardedAd;
    private static final String Rewarded = "ca-app-pub-3940256099942544/5224354917";
    private boolean isLoading;


    private boolean timerads = true;

    private String bannerId = "ca-app-pub-3940256099942544/6300978111";


    private boolean mShowInterAdsAuto = true;

    private AdmobHelper.RewardedListener rewardlistener;

    private RelativeLayout bannerView; 

    public interface RewardedListener {
        void onLoad();
        void onLoaded();
        void onReward(RewardItem rewarditem);
        void onFaild();
    }


    public AdmobHelper setMobileAdsId(String id)
    {

        return this;
    }

    public AdmobHelper setBannerView(RelativeLayout v)
    {
        this.bannerView = v;
		//adView.setId(123);
		/*TextView tv = new TextView(context);
		 // Create a LayoutParams for TextView
		 LayoutParams lp = new RelativeLayout.LayoutParams(
		 LayoutParams.WRAP_CONTENT, // Width of TextView
		 LayoutParams.WRAP_CONTENT); // Height of TextView
		 lp.addRule(RelativeLayout.RIGHT_OF, adView.getId());
		 // Apply the layout parameters to TextView widget
		 tv.setLayoutParams(lp);

		 // Set text to display in TextView
		 tv.setText("Close (x)");
		 // Set a text color for TextView text
		 tv.setTextColor(Color.WHITE);
		 tv.setBackgroundColor(Color.RED);
		 tv.setOnClickListener(new View.OnClickListener() {
		 @Override
		 public void onClick(View p1)
		 {
		 bannerView.setVisibility(View.GONE);
		 }
		 });*/
        bannerView.addView(adView);
		//bannerView.addView(tv);
        return this;
    }

    public AdmobHelper setBannerId(String id)
    {
        bannerId = id;
        adView.setAdUnitId(id);
        return this;
    }

    public AdmobHelper setBannerSize(AdSize size)
    {
        adView.setAdSize(size);
        return this;
    }

    public AdmobHelper setIntertitialId(String id)
    {

        return this;
    }

    public AdmobHelper setRewardedId(String id)
    {

        return this;
    }

    public AdmobHelper setRewardAdsListener(RewardedListener listener)
    {
        rewardlistener = listener;

        return this;
    }

    public AdmobHelper setTestDevice(String device_id)
    {

        return this;
    }

    public AdmobHelper setShowInterAdsAuto(boolean status) {
        mShowInterAdsAuto = status;
        return this;
    }

    public AdmobHelper setAdsListener(AdListener listener)
    {
        if (adView != null)
        {
            adView.setAdListener(listener);
        }
        return this;
    }

    public AdmobHelper buildAdsRequest()
    {
        adR = adRequest.build();
        return this;
    }

    public AdmobHelper loadBannerAdsRequest()
    {
        if (!bannerId.isEmpty())
        {
            adView.loadAd(adR);
        }
        return this;
    }

    public AdmobHelper loadAdsRequest()
    {
        if (!bannerId.isEmpty())
        {
            adView.loadAd(adR);
        }


        return this;
    }

	public void loadIntertitial() {

	}

    public void loadRewardedAds() {

    }

    public AdmobHelper initTimerAds(int time)
    {
        timerads = true;
        final Handler handler = new Handler();
        Timer timer = new Timer();
        TimerTask doAsynchronousTask = new TimerTask() {
            @Override
            public void run()
            {
                handler.post(new Runnable() {
                        public void run()
                        {
                            if (adR != null)
                            {
                                if (!bannerId.isEmpty())
                                {
                                    adView.loadAd(adR);
                                }

                            }
                        }
                    });
            }
        };
        timer.schedule(doAsynchronousTask, 0, time);
        return this;
    }

    public void reloadAds()
    {
        if (!timerads)
        {
            if (adR != null)
            {
                if (!bannerId.isEmpty())
                {
                    adView.loadAd(adR);
                }

            }
        }



    };
}






