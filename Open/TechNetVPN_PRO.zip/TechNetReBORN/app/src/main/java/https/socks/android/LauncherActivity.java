package https.socks.android;
import android.app.Application;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.widget.TextView;

import https.socks.android.activities.BaseActivity;

public class LauncherActivity extends BaseActivity
	{

		private TextView versionCode;
		private static final long COUNTER_TIME = 5;
		private long secondsRemaining;

		Handler handler;
		@Override
		protected void onCreate(Bundle savedInstanceState) {

			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_splash_screen);
			new Handler(getMainLooper()).postDelayed(() -> {
				//Intent intent = new Intent(this, SocksHttpMainActivity.class);
				//intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
				//startActivity(intent);
				//finish();
				createTimer(COUNTER_TIME);
			}, 500);
		}

		private void createTimer(long seconds) {
			//final TextView counterTextView = findViewById(R.id.timer);

			CountDownTimer countDownTimer =
					new CountDownTimer(seconds * 1000, 1000) {
						@Override
						public void onTick(long millisUntilFinished) {
							secondsRemaining = ((millisUntilFinished / 1000) + 1);
							//counterTextView.setText("App is done loading in: " + secondsRemaining);
						}

						@Override
						public void onFinish() {
							secondsRemaining = 0;
							//counterTextView.setText("Done.");

							Application application = getApplication();

							// If the application is not an instance of MyApplication, log an error message and
							// start the MainActivity without showing the app open ad.
							if (!(application instanceof SocksHttpApp)) {
								//Log.e(LOG_TAG, "Failed to cast application to MyApplication.");
								startMainActivity();
								return;
							}

							// Show the app open ad.
							((SocksHttpApp) application)
									.showAdIfAvailable(
											LauncherActivity.this,
											new SocksHttpApp.OnShowAdCompleteListener() {
												@Override
												public void onShowAdComplete() {
													startMainActivity();
												}
											});
						}
					};
			countDownTimer.start();
		}

		public void startMainActivity() {
			Intent intent = new Intent(this, MainActivity.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
			startActivity(intent);
		}

		public String getVersionName() {
			String oldVerName = "";
			try {
				PackageInfo vc = getApplicationContext().getPackageManager().getPackageInfo(getPackageName(), 0);
				oldVerName = vc.versionName;
			} catch (PackageManager.NameNotFoundException e) {}
			return oldVerName;
		}

		public int getVersionCode() {
			int oldVerCode = 0;
			try {
				PackageInfo vc = getApplicationContext().getPackageManager().getPackageInfo(getPackageName(), 0);
				oldVerCode = vc.versionCode;
			} catch (PackageManager.NameNotFoundException e) {}
			return oldVerCode;
		}

	}

